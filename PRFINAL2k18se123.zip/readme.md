In the, basically we will have to download xml files from (https://github.com/opencv/opencv/tree/master/data/haarcascades).
After this, while writing code for smile and smileandeye, we will have to enter the right path to our downloaded files.
As well as for training images, we will have to create a file whose correct path is to be put in the code.
Rest, all images arrays will automatically be stored there.
Doing this, everything will run smoothly.